CREATE DATABASE Empresa;
USE Empresa;

-- Tabla CARGO
CREATE TABLE Cargo (
  id_cargo INT PRIMARY KEY,
  nombre_cargo VARCHAR(50) NOT NULL
);

-- Tabla EMPLEADO
CREATE TABLE Empleado (
  id_empleado INT PRIMARY KEY,
  nombre_empleado VARCHAR(100) NOT NULL,
  edad INT,
  id_cargo INT,  -- Llave foránea
  FOREIGN KEY (id_cargo) REFERENCES Cargo(id_cargo)
);

-- Tabla PROYECTO
CREATE TABLE Proyecto (
  id_proyecto INT PRIMARY KEY,
  nombre_proyecto VARCHAR(100) NOT NULL,
  descripcion TEXT
);
-- Tabla intermedia para relación muchos a muchos
CREATE TABLE Empleado_Proyecto (
  id_empleado INT,
  id_proyecto INT,
  PRIMARY KEY (id_empleado, id_proyecto),
  FOREIGN KEY (id_empleado) REFERENCES Empleado(id_empleado),
  FOREIGN KEY (id_proyecto) REFERENCES Proyecto(id_proyecto)
);
-- Insertar datos en la tabla Cargo
INSERT INTO Cargo VALUES
(1, 'Gerente'),
(2, 'Analista'),
(3, 'Desarrollador');

-- Insertar datos en la tabla Empleado
INSERT INTO Empleado VALUES
(1, 'Carlos Pérez', 35, 1),
(2, 'Laura Gómez', 28, 2),
(3, 'Juan Torres', 25, 3);

-- Insertar datos en la tabla Proyecto
INSERT INTO Proyecto VALUES
(1, 'Sistema de Ventas', 'Desarrollo de una plataforma de ventas online'),
(2, 'Gestión de Recursos Humanos', 'Proyecto para automatizar procesos internos');

-- Insertar datos en la tabla Empleado_Proyecto
INSERT INTO Empleado_Proyecto VALUES
(1, 1),
(2, 1),
(3, 2);
INSERT INTO Cargo VALUES
(1, 'Gerente'),
(2, 'Analista'),
(3, 'Desarrollador'),
(4, 'Técnico'),
(5, 'Asistente'),
(6, 'Coordinador'),
(7, 'Administrador'),
(8, 'Contador'),
(9, 'Diseñador'),
(10, 'Supervisor'),
(11, 'Operario'),
(12, 'Consultor'),
(13, 'Auditor'),
(14, 'Programador'),
(15, 'Vendedor'),
(16, 'Recepcionista'),
(17, 'Director'),
(18, 'Especialista'),
(19, 'Jefe de Área'),
(20, 'Ingeniero'),
(21, 'Capacitador'),
(22, 'Logístico'),
(23, 'Secretario'),
(24, 'Soporte Técnico'),
(25, 'Asesor');

INSERT INTO Empleado VALUES
(1, 'Carlos Pérez', 35, 1),
(2, 'Laura Gómez', 28, 2),
(3, 'Juan Torres', 25, 3),
(4, 'María Rodríguez', 40, 4),
(5, 'Andrés Martínez', 30, 5),
(6, 'Luisa Fernández', 27, 6),
(7, 'José Ramírez', 38, 7),
(8, 'Ana Castro', 26, 8),
(9, 'Camilo Morales', 31, 9),
(10, 'Daniela Ríos', 29, 10),
(11, 'Felipe Duarte', 33, 11),
(12, 'Sandra Ruiz', 24, 12),
(13, 'Paola Restrepo', 37, 13),
(14, 'Javier Sánchez', 32, 14),
(15, 'Tatiana López', 23, 15),
(16, 'Ricardo Muñoz', 36, 16),
(17, 'Valentina Gómez', 21, 17),
(18, 'Esteban Cárdenas', 34, 18),
(19, 'Diana Silva', 28, 19),
(20, 'Kevin Ortiz', 22, 20),
(21, 'Nicolás Herrera', 27, 21),
(22, 'Sofía Morales', 29, 22),
(23, 'Fernando Arias', 41, 23),
(24, 'Melissa Cruz', 26, 24),
(25, 'Julián Peña', 39, 25);


INSERT INTO Proyecto VALUES
(1, 'Sistema de Ventas', 'Desarrollo de plataforma web'),
(2, 'Gestión de RRHH', 'Automatización de nómina'),
(3, 'Control de Inventario', 'Monitoreo de existencias'),
(4, 'Portal de Clientes', 'Sitio web para clientes'),
(5, 'App Móvil de Servicios', 'Aplicación Android'),
(6, 'Digitalización de Archivos', 'Proyecto de gestión documental'),
(7, 'Sistema de Facturación', 'Implementación ERP'),
(8, 'Control de Producción', 'Software industrial'),
(9, 'Marketing Digital', 'Estrategia en redes sociales'),
(10, 'Proyecto Ambiental', 'Gestión de residuos'),
(11, 'Reclutamiento Online', 'Plataforma de empleos'),
(12, 'Automatización Contable', 'Integración de procesos'),
(13, 'Seguridad Informática', 'Mejora de protocolos'),
(14, 'Análisis de Datos', 'Big Data y reportes'),
(15, 'Optimización de Transporte', 'Ruta de entregas'),
(16, 'Desarrollo Web Corporativo', 'Nueva página institucional'),
(17, 'Capacitación Interna', 'Entrenamiento de empleados'),
(18, 'Proyecto Energético', 'Uso de energía solar'),
(19, 'Sistema de Compras', 'Gestión de proveedores'),
(20, 'Atención al Cliente', 'Sistema de soporte'),
(21, 'Reingeniería de Procesos', 'Rediseño interno'),
(22, 'Gestión de Calidad', 'Certificación ISO'),
(23, 'Innovación Tecnológica', 'Implementación de IA'),
(24, 'Proyecto Social', 'Apoyo a comunidades'),
(25, 'Mantenimiento Preventivo', 'Plan de equipos');


INSERT INTO Empleado_Proyecto VALUES
(1, 1), (2, 1), (3, 2), (4, 2), (5, 3),
(6, 3), (7, 4), (8, 4), (9, 5), (10, 6),
(11, 7), (12, 8), (13, 9), (14, 9), (15, 10),
(16, 11), (17, 12), (18, 13), (19, 14), (20, 15),
(21, 16), (22, 17), (23, 18), (24, 19), (25, 20);
